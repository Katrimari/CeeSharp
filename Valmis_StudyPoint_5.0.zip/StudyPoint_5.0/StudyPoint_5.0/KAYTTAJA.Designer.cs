﻿namespace StudyPoint_5._0
{
    partial class KAYTTAJA
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.panel2 = new System.Windows.Forms.Panel();
            this.PnroLB = new System.Windows.Forms.Label();
            this.PtpLB = new System.Windows.Forms.Label();
            this.LahOsLB = new System.Windows.Forms.Label();
            this.SpostiLB = new System.Windows.Forms.Label();
            this.puhLB = new System.Windows.Forms.Label();
            this.snimiLB = new System.Windows.Forms.Label();
            this.enimiLB = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.KirjauduUlosBT = new System.Windows.Forms.Button();
            this.KayttajaNimiLB = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.KayttajaNimiTB = new System.Windows.Forms.TextBox();
            this.oPISKELIJABindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.oPISKELIJABindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.kIRJAUDUBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.oPISKELIJABindingSource2 = new System.Windows.Forms.BindingSource(this.components);
            this.oPISKELIJABindingSource3 = new System.Windows.Forms.BindingSource(this.components);
            this.button1 = new System.Windows.Forms.Button();
            this.panel2.SuspendLayout();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.oPISKELIJABindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.oPISKELIJABindingSource1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.kIRJAUDUBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.oPISKELIJABindingSource2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.oPISKELIJABindingSource3)).BeginInit();
            this.SuspendLayout();
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.RoyalBlue;
            this.panel2.Controls.Add(this.PnroLB);
            this.panel2.Controls.Add(this.PtpLB);
            this.panel2.Controls.Add(this.LahOsLB);
            this.panel2.Controls.Add(this.SpostiLB);
            this.panel2.Controls.Add(this.puhLB);
            this.panel2.Controls.Add(this.snimiLB);
            this.panel2.Controls.Add(this.enimiLB);
            this.panel2.Controls.Add(this.label1);
            this.panel2.Location = new System.Drawing.Point(364, 131);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(775, 529);
            this.panel2.TabIndex = 3;
            // 
            // PnroLB
            // 
            this.PnroLB.AutoSize = true;
            this.PnroLB.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.PnroLB.ForeColor = System.Drawing.SystemColors.Control;
            this.PnroLB.Location = new System.Drawing.Point(24, 460);
            this.PnroLB.Name = "PnroLB";
            this.PnroLB.Size = new System.Drawing.Size(110, 23);
            this.PnroLB.TabIndex = 11;
            this.PnroLB.Text = "Postinumero";
            // 
            // PtpLB
            // 
            this.PtpLB.AutoSize = true;
            this.PtpLB.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.PtpLB.ForeColor = System.Drawing.SystemColors.Control;
            this.PtpLB.Location = new System.Drawing.Point(24, 408);
            this.PtpLB.Name = "PtpLB";
            this.PtpLB.Size = new System.Drawing.Size(138, 23);
            this.PtpLB.TabIndex = 10;
            this.PtpLB.Text = "Postitoimipaikka";
            // 
            // LahOsLB
            // 
            this.LahOsLB.AutoSize = true;
            this.LahOsLB.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LahOsLB.ForeColor = System.Drawing.SystemColors.Control;
            this.LahOsLB.Location = new System.Drawing.Point(24, 359);
            this.LahOsLB.Name = "LahOsLB";
            this.LahOsLB.Size = new System.Drawing.Size(88, 23);
            this.LahOsLB.TabIndex = 9;
            this.LahOsLB.Text = "Lähiosoite";
            // 
            // SpostiLB
            // 
            this.SpostiLB.AutoSize = true;
            this.SpostiLB.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SpostiLB.ForeColor = System.Drawing.SystemColors.Control;
            this.SpostiLB.Location = new System.Drawing.Point(24, 316);
            this.SpostiLB.Name = "SpostiLB";
            this.SpostiLB.Size = new System.Drawing.Size(95, 23);
            this.SpostiLB.TabIndex = 8;
            this.SpostiLB.Text = "Sähköposti";
            // 
            // puhLB
            // 
            this.puhLB.AutoSize = true;
            this.puhLB.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.puhLB.ForeColor = System.Drawing.SystemColors.Control;
            this.puhLB.Location = new System.Drawing.Point(24, 273);
            this.puhLB.Name = "puhLB";
            this.puhLB.Size = new System.Drawing.Size(128, 23);
            this.puhLB.TabIndex = 7;
            this.puhLB.Text = "Puhelinnumero";
            // 
            // snimiLB
            // 
            this.snimiLB.AutoSize = true;
            this.snimiLB.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.snimiLB.ForeColor = System.Drawing.SystemColors.Control;
            this.snimiLB.Location = new System.Drawing.Point(24, 232);
            this.snimiLB.Name = "snimiLB";
            this.snimiLB.Size = new System.Drawing.Size(81, 23);
            this.snimiLB.TabIndex = 6;
            this.snimiLB.Text = "Sukunimi";
            // 
            // enimiLB
            // 
            this.enimiLB.AutoSize = true;
            this.enimiLB.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.enimiLB.ForeColor = System.Drawing.SystemColors.Control;
            this.enimiLB.Location = new System.Drawing.Point(24, 189);
            this.enimiLB.Name = "enimiLB";
            this.enimiLB.Size = new System.Drawing.Size(68, 23);
            this.enimiLB.TabIndex = 5;
            this.enimiLB.Text = "Etunimi";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Calibri", 26.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.Control;
            this.label1.Location = new System.Drawing.Point(21, 118);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(119, 42);
            this.label1.TabIndex = 1;
            this.label1.Text = "Tietoja";
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.RoyalBlue;
            this.panel1.Controls.Add(this.button1);
            this.panel1.Controls.Add(this.KayttajaNimiTB);
            this.panel1.Controls.Add(this.KirjauduUlosBT);
            this.panel1.Controls.Add(this.KayttajaNimiLB);
            this.panel1.Controls.Add(this.pictureBox1);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(206, 756);
            this.panel1.TabIndex = 2;
            // 
            // KirjauduUlosBT
            // 
            this.KirjauduUlosBT.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.KirjauduUlosBT.Location = new System.Drawing.Point(3, 700);
            this.KirjauduUlosBT.Name = "KirjauduUlosBT";
            this.KirjauduUlosBT.Size = new System.Drawing.Size(199, 53);
            this.KirjauduUlosBT.TabIndex = 5;
            this.KirjauduUlosBT.Text = "Kirjaudu Ulos";
            this.KirjauduUlosBT.UseVisualStyleBackColor = true;
            this.KirjauduUlosBT.Click += new System.EventHandler(this.KirjauduUlosBT_Click);
            // 
            // KayttajaNimiLB
            // 
            this.KayttajaNimiLB.AutoSize = true;
            this.KayttajaNimiLB.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.KayttajaNimiLB.ForeColor = System.Drawing.SystemColors.Control;
            this.KayttajaNimiLB.Location = new System.Drawing.Point(34, 163);
            this.KayttajaNimiLB.Name = "KayttajaNimiLB";
            this.KayttajaNimiLB.Size = new System.Drawing.Size(53, 15);
            this.KayttajaNimiLB.TabIndex = 1;
            this.KayttajaNimiLB.Text = "Käyttäjä";
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackgroundImage = global::StudyPoint_5._0.Properties.Resources.male_user_50px;
            this.pictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pictureBox1.Location = new System.Drawing.Point(37, 32);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(126, 114);
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // KayttajaNimiTB
            // 
            this.KayttajaNimiTB.Location = new System.Drawing.Point(22, 181);
            this.KayttajaNimiTB.Name = "KayttajaNimiTB";
            this.KayttajaNimiTB.Size = new System.Drawing.Size(166, 20);
            this.KayttajaNimiTB.TabIndex = 6;
            // 
            // oPISKELIJABindingSource
            // 
            this.oPISKELIJABindingSource.DataSource = typeof(StudyPoint_5._0.OPISKELIJA);
            // 
            // oPISKELIJABindingSource1
            // 
            this.oPISKELIJABindingSource1.DataSource = typeof(StudyPoint_5._0.OPISKELIJA);
            // 
            // kIRJAUDUBindingSource
            // 
            this.kIRJAUDUBindingSource.DataSource = typeof(StudyPoint_5._0.KIRJAUDU);
            // 
            // oPISKELIJABindingSource2
            // 
            this.oPISKELIJABindingSource2.DataSource = typeof(StudyPoint_5._0.OPISKELIJA);
            // 
            // oPISKELIJABindingSource3
            // 
            this.oPISKELIJABindingSource3.DataSource = typeof(StudyPoint_5._0.OPISKELIJA);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(52, 238);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(91, 26);
            this.button1.TabIndex = 7;
            this.button1.Text = "button1";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // KAYTTAJA
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::StudyPoint_5._0.Properties.Resources.technology;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Name = "KAYTTAJA";
            this.Size = new System.Drawing.Size(1396, 756);
            this.Load += new System.EventHandler(this.KAYTTAJA_Load);
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.oPISKELIJABindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.oPISKELIJABindingSource1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.kIRJAUDUBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.oPISKELIJABindingSource2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.oPISKELIJABindingSource3)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label PnroLB;
        private System.Windows.Forms.Label PtpLB;
        private System.Windows.Forms.Label LahOsLB;
        private System.Windows.Forms.Label SpostiLB;
        private System.Windows.Forms.Label puhLB;
        private System.Windows.Forms.Label snimiLB;
        private System.Windows.Forms.Label enimiLB;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button KirjauduUlosBT;
        private System.Windows.Forms.Label KayttajaNimiLB;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.TextBox KayttajaNimiTB;
        private System.Windows.Forms.BindingSource oPISKELIJABindingSource;
        private System.Windows.Forms.BindingSource oPISKELIJABindingSource1;
        private System.Windows.Forms.BindingSource kIRJAUDUBindingSource;
        private System.Windows.Forms.BindingSource oPISKELIJABindingSource2;
        private System.Windows.Forms.BindingSource oPISKELIJABindingSource3;
        private System.Windows.Forms.Button button1;
    }
}
