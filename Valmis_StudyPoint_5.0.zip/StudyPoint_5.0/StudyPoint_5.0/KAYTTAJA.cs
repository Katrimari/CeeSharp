﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;



namespace StudyPoint_5._0
{
    public partial class KAYTTAJA : UserControl
    {
        private KIRJAUDU kirjaudu;


        public KAYTTAJA()
        {
            InitializeComponent();
        }

        private void KirjauduUlosBT_Click(object sender, EventArgs e)
        {
            DialogResult Exit;

            try
            {
                Exit = MessageBox.Show("Haluatko varmasti kirjautua ulos?", "Uloskirjautuminen", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

                if (Exit == DialogResult.Yes)
                {
                    Application.Exit();
                }


            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void KAYTTAJA_Load(object sender, EventArgs e)
        {
           /* if (kirjaudu != null)
            {
                KayttajaNimiTB.Text = kirjaudu.KayttajatnsTB.Text;
            }
            else
            {
                KayttajaNimiTB.Text = kirjaudu.KayttajatnsTB.Text;
            }*/
        }

        private void button1_Click(object sender, EventArgs e)
        {
            KayttajaNimiTB.Text = kirjaudu.KayttajatnsTB.Text;
        }
    }
}
